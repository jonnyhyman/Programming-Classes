#I.D.P
print("Hello World")
#Imports \/
from PyQt5 import QtCore, QtWidgets, QtGui
import DysGame
from DysGame import DysDystopia #?
import sys
#Interfaces \/

#Main Menu Interface
class MM(QtWidgets.QMainWindow):
    """Main Menui"""
    def __init__(self):
        super(MM, self).__init__()
        self.show()
        self.setWindowTitle( "DysEngine" )
        self.setObjectName('MM')
        self.setStyleSheet("QWidget#MM {background-image: url(Placeholder.jpg);}")
        self.resize(1020, 520)
        self.CentralWidget = QtWidgets.QWidget()
        self.setCentralWidget(self.CentralWidget)
        self.buttons = QtWidgets.QFrame(self.CentralWidget)
        self.giovannis = QtWidgets.QVBoxLayout(self.buttons)
        self.buttons.setGeometry(100,70,200,65)
        self.buttons.setToolTip('Now you click the buttons')
        #self.buttons.setStyleSheet('background: red;')
        self.mmbutton = QtWidgets.QPushButton("PLAY?",parent=self.buttons)
        self.mmbutton.clicked.connect(self.on_click)
        self.giovannis.addWidget(self.mmbutton)
        self.mmbutton0 = QtWidgets.QPushButton("SETTINGS",parent=self.buttons)
        self.giovannis.addWidget(self.mmbutton0)
    def on_click(self):
        print("Launching HL3")
        self.game = DysDystopia()





if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    exe = MM()
    sys.exit(app.exec_())

#Collision laws \/


#Local Interaction Laws \/


#Effects \/


#Animations \/


#Sound Laws and Actions \/


#Combat System \/


#Building Laws and Actions \/


#Entity Laws \/ (aka meaning of life)


#World Generation \/


#Event Generation \/


#Difficulty Laws \/


#Multiplayer Systems?
