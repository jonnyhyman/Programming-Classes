from PyQt5 import QtCore, QtWidgets, QtGui
import sys
#from InterNet fix Errors

class DysDystopia(QtWidgets.QMainWindow):
    """DysDystopia"""
    def __init__(self,parent = None):
        super(DysDystopia, self).__init__(parent = parent)

        self.setWindowTitle("DysEngine ver-0")
        self.setObjectName('DysEngine')
        #self.setStyleSheet("QWidget#DysEngine {background-image: url(DysGamePlaceholder.jpg);}")
        self.scene = QtWidgets.QGraphicsScene(parent = self)
        self.view = QtWidgets.QGraphicsView(self.scene, parent = self)

        self.show()
        self.showMaximized()

    def resizeEvent(self, event):
        self.width = self.geometry().width()
        self.height = self.geometry().height()
        self.view.setGeometry(0,0,self.width, self.height)
        
